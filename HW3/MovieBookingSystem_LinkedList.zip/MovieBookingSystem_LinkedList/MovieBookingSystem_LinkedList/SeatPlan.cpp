#include "SeatPlan.h"
#include <cstddef>

SeatPlan::SeatPlan() : size(0), head(NULL) {

}
SeatPlan::SeatPlan(const SeatPlan& aList) : size(aList.size) {
    if (aList.head == NULL)
        head = NULL;  // original list is empty
    else {
        // copy first node
        head = new SeatNode;
        head->seat = aList.head->seat;

        // copy rest of list
        SeatNode* newPtr = head;  // new list ptr

        for (SeatNode* origPtr = aList.head->next;
            origPtr != NULL;
            origPtr = origPtr->next) {
            newPtr->next = new SeatNode;
            newPtr = newPtr->next;
            newPtr->seat = origPtr->seat;
        }
        newPtr->next = NULL;
    }
}  // end copy constructor
SeatPlan::~SeatPlan() {

    while (!isEmpty())
        remove(1);

} // end destructor
bool SeatPlan::isEmpty() const {

    return size == 0;

}  // end isEmpty
int SeatPlan::getLength() const {

    return size;

}  // end getLength
SeatPlan::SeatNode* SeatPlan::find(int index) const {
    // Locates a specified node in a linked list.
    // Precondition: index is the number of the
    // desired node.
    // Postcondition: Returns a pointer to the 
    // desired node. If index < 1 or index > the 
    // number of nodes in the list, returns NULL.

    if ((index < 1) || (index > getLength()))
        return NULL;

    else { // count from the beginning of the list
        SeatNode* cur = head;
        for (int skip = 1; skip < index; ++skip) {
            cur = cur->next;
        }
        return cur;
    }
}  // end find
bool SeatPlan::retrieve(int index, int& seat_obj) const {

    if ((index < 1) || (index > getLength()))
        return false;

    // get pointer to node, then data in node
    SeatNode* cur = find(index);
    seat_obj = cur->seat;

    return true;

} // end retrieve
bool SeatPlan::insert(int index, int seat_obj) {

    int newLength = getLength() + 1;

    if ((index < 1) || (index > newLength))
        return false;

    SeatNode* newPtr = new SeatNode;
    size = newLength;
    newPtr->seat = seat_obj;

    if (index == 1) {
        newPtr->next = head;
        head = newPtr;
    }
    else {
        SeatNode* prev = find(index - 1);
        newPtr->next = prev->next;
        prev->next = newPtr;
    }
    return true;

} // end insert
bool SeatPlan::remove(int index) {

    SeatNode* cur;

    if ((index < 1) || (index > getLength()))
        return false;

    --size;
    if (index == 1) {
        cur = head;
        head = head->next;
    }
    else {
        SeatNode* prev = find(index - 1);
        cur = prev->next;
        prev->next = cur->next;
    }
    cur->next = NULL;
    delete cur;
    cur = NULL;

    return true;

}  // end remove
