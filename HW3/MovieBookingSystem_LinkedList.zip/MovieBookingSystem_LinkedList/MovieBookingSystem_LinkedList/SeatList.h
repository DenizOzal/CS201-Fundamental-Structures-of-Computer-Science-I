#include "SeatPlan.h"

class SeatList {
public:
	SeatList();
	SeatList(const SeatList& aList);
	~SeatList();
	bool isEmpty() const;
	int getLength() const;
	bool retrieve(int index, SeatPlan& seats_obj) const;
	bool insert(int index, SeatPlan seats_obj);
	bool remove(int index);
private:
	struct SeatListNode {
		SeatPlan seats;
		SeatListNode* next;
	};
	int size;
	SeatListNode* head;
	SeatListNode* find(int index) const;
};