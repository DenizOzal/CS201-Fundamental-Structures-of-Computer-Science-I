class SeatPlan{
public:
	SeatPlan();
	SeatPlan(const SeatPlan& aList);
	~SeatPlan();
	bool isEmpty() const;
	int getLength() const;
	bool retrieve(int index, int& seat_obj) const;
	bool insert(int index, int seat_obj);
	bool remove(int index);
private:
	struct SeatNode {
		int seat;
		SeatNode* next;
	};
	int size;
	SeatNode* head;
	SeatNode* find(int index) const;
};