#pragma once

using namespace std;
class Movie {
public:
	Movie();
	~Movie();
	long getMovie_ID();
	int getAudienceRadius();
	int getNumOfSeats();
	int getNoOfRow();
	int getNoOfColumn();
	int getResCode();
	void setMovie_ID(const long movie_id);
	void setAudienceRadius(const int movie_radius);
	void setNumOfSeats(const int movie_total_seat);
	void setNoOfRow(const int movie_noOfRow);
	void setNoOfColumn(const int movie_noOfColumn);
	void setResCode(const int res_code);
	
private:
	long movie_ID;
	int numOfSeats;
	int audienceRadius;
	int noOfRow;
	int noOfColumn;
	int resCode;
};

